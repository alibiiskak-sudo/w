# FeriuxAI on InfinityFree

This folder contains the PHP/MySQL adapter for InfinityFree. The React build is static; PHP handles account registration and sessions. Groq, OpenRouter, and Tavily keys are entered by each user and sent directly from their browser to the corresponding provider. The app does not save those keys.

## Prepare the files

1. Run `pnpm --filter @workspace/feriuxai run package:infinityfree`. This creates `generated-artifacts/feriuxai-infinityfree.zip`.
2. Upload the ZIP contents into InfinityFree's `htdocs/` folder.
3. In the InfinityFree control panel, create a MySQL database and import `schema.sql` using phpMyAdmin.
4. Copy `config.example.php` to `config.php` in `htdocs/`, then replace its four database placeholders with the MySQL host, database name, username, and password shown by InfinityFree. Never upload real credentials in `config.example.php`. `.htaccess` blocks both config files from web access.
5. Confirm the hosting account has PHP 8.1+, PDO MySQL, and HTTPS enabled. Open the site, create an account, then enter Groq/OpenRouter keys for chat and a Tavily key for web search in Settings.

## Notes

- The SQL schema here is for InfinityFree's MySQL database. It is separate from the PostgreSQL account table used by the Replit preview.
- Account passwords are hashed with PHP `password_hash`; sessions use secure, HTTP-only, SameSite cookies.
- API keys are intentionally not sent to this PHP API or stored in the browser's persistent storage. They remain in page memory and are sent directly to Groq, OpenRouter, or Tavily.
- Tavily web search requires the user to provide a Tavily API key in Settings. Tavily's API plan and usage limits apply.
- Provider limits are not bypassed. A provider's 429 or quota error is shown to the user; the app does not rotate keys or retry paid generation automatically.
- The provider must offer the selected model in its live model catalog. If a requested model is absent, select an available model rather than sending a made-up model ID.
