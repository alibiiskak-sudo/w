<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

function respond(int $status, array $data): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function request_body(): array
{
    $decoded = json_decode((string) file_get_contents('php://input'), true);
    return is_array($decoded) ? $decoded : [];
}

function email_value(mixed $value): ?string
{
    if (!is_string($value)) {
        return null;
    }
    $email = strtolower(trim($value));
    return strlen($email) <= 254 && filter_var($email, FILTER_VALIDATE_EMAIL)
        ? $email
        : null;
}

function public_user(array $row): array
{
    return [
        'id' => (string) $row['id'],
        'email' => (string) $row['email'],
        'createdAt' => gmdate('c', strtotime((string) $row['created_at'])),
    ];
}

function same_origin_request(): bool
{
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin === '') {
        return true;
    }
    $originHost = parse_url($origin, PHP_URL_HOST);
    $requestHost = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
    return is_string($originHost) && strtolower($originHost) === preg_replace('/:\d+$/', '', $requestHost);
}

$configPath = __DIR__ . '/config.php';
if (!is_file($configPath)) {
    respond(503, ['error' => 'Database configuration is missing. Follow README.md before using this site.']);
}
$config = require $configPath;
if (!is_array($config)) {
    respond(503, ['error' => 'Database configuration is invalid.']);
}

$secureCookie = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
session_name('feriuxai_session');
session_set_cookie_params([
    'lifetime' => 60 * 60 * 24 * 30,
    'path' => '/',
    'secure' => $secureCookie,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

$route = (string) ($_GET['route'] ?? '');
$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if ($method !== 'GET' && !same_origin_request()) {
    respond(403, ['error' => 'Request origin was not accepted.']);
}

try {
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        (string) ($config['db_host'] ?? ''),
        (string) ($config['db_name'] ?? '')
    );
    $pdo = new PDO($dsn, (string) ($config['db_user'] ?? ''), (string) ($config['db_password'] ?? ''), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Throwable $error) {
    respond(503, ['error' => 'The account database is unavailable. Check the InfinityFree database settings.']);
}

if ($route === '/auth/register' && $method === 'POST') {
    $body = request_body();
    $email = email_value($body['email'] ?? null);
    $password = $body['password'] ?? null;
    if ($email === null || !is_string($password) || strlen($password) < 10 || strlen($password) > 512) {
        respond(400, ['error' => 'Enter a valid email and a password of at least 10 characters.']);
    }

    $check = $pdo->prepare('SELECT id FROM feriuxai_users WHERE email = :email LIMIT 1');
    $check->execute(['email' => $email]);
    if ($check->fetch()) {
        respond(409, ['error' => 'An account with that email already exists.']);
    }

    $id = bin2hex(random_bytes(16));
    try {
        $insert = $pdo->prepare(
            'INSERT INTO feriuxai_users (id, email, password_hash) VALUES (:id, :email, :password_hash)'
        );
        $insert->execute([
            'id' => $id,
            'email' => $email,
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        ]);
    } catch (PDOException $error) {
        if ($error->getCode() === '23000') {
            respond(409, ['error' => 'An account with that email already exists.']);
        }
        respond(500, ['error' => 'Account could not be created. Please try again.']);
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = $id;
    $select = $pdo->prepare('SELECT id, email, created_at FROM feriuxai_users WHERE id = :id');
    $select->execute(['id' => $id]);
    $user = $select->fetch();
    respond(201, public_user($user));
}

if ($route === '/auth/login' && $method === 'POST') {
    $body = request_body();
    $email = email_value($body['email'] ?? null);
    $password = $body['password'] ?? null;
    if ($email === null || !is_string($password) || $password === '' || strlen($password) > 512) {
        respond(400, ['error' => 'Email or password is incorrect.']);
    }
    $select = $pdo->prepare(
        'SELECT id, email, password_hash, created_at FROM feriuxai_users WHERE email = :email LIMIT 1'
    );
    $select->execute(['email' => $email]);
    $row = $select->fetch();
    if (!$row || !password_verify($password, (string) $row['password_hash'])) {
        respond(400, ['error' => 'Email or password is incorrect.']);
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = (string) $row['id'];
    respond(200, public_user($row));
}

if ($route === '/auth/logout' && $method === 'POST') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires' => time() - 42000,
            'path' => $params['path'],
            'domain' => $params['domain'],
            'secure' => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => 'Lax',
        ]);
    }
    session_destroy();
    respond(200, ['status' => 'signed-out']);
}

if ($route === '/auth/me' && $method === 'GET') {
    $id = $_SESSION['user_id'] ?? null;
    if (!is_string($id)) {
        respond(401, ['error' => 'Sign in to continue.']);
    }
    $select = $pdo->prepare('SELECT id, email, created_at FROM feriuxai_users WHERE id = :id LIMIT 1');
    $select->execute(['id' => $id]);
    $user = $select->fetch();
    if (!$user) {
        respond(401, ['error' => 'Sign in to continue.']);
    }
    respond(200, public_user($user));
}

respond(404, ['error' => 'API route not found.']);
