<?php
declare(strict_types=1);

return [
    'db_host' => 'YOUR_INFINITYFREE_MYSQL_HOST',
    'db_name' => 'YOUR_INFINITYFREE_DATABASE_NAME',
    'db_user' => 'YOUR_INFINITYFREE_DATABASE_USER',
    'db_password' => 'YOUR_INFINITYFREE_DATABASE_PASSWORD',
];
